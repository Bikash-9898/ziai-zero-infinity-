// src/components/image/ImageModelSelector.tsx
import { useEffect, useRef, useState } from 'react';
import { ChevronDown, Loader2 } from 'lucide-react';
import { apiJson } from '@/api/apiClient';   // ← JWT-aware, no hardcoded URL
import type { ImageModel } from '@/types/image';

interface Props {
  value: string;
  onChange: (modelId: string) => void;
  onModelsLoaded?: (models: ImageModel[]) => void;   // ← from new branch
}

export default function ImageModelSelector({ value, onChange, onModelsLoaded }: Props) {
  const [models, setModels]   = useState<ImageModel[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen]       = useState(false);
  const onModelsLoadedRef     = useRef(onModelsLoaded);  // ← stable ref

  useEffect(() => {
    apiJson<ImageModel[]>('/image/models')
      .then(data => {
        setModels(data);
        onModelsLoadedRef.current?.(data);   // ← use ref, not prop directly
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);   // ← empty array, runs once only

  const selected = models.find(m => m.id === value);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(v => !v)}
        className="flex items-center gap-2 bg-slate-900 border border-slate-800 hover:border-slate-600 rounded-lg px-3 py-2 text-[11px] font-mono text-slate-400 transition-all min-w-40"
      >
        {loading ? (
          <Loader2 size={11} className="animate-spin text-slate-600" />
        ) : (
          <>
            <span className="flex-1 text-left">
              {selected?.name ?? 'Select model'}
            </span>
            {selected && (
              <span className="text-[9px] text-slate-600 bg-slate-800 px-1.5 py-0.5 rounded">
                {selected.credits_per_image}cr
              </span>
            )}
            <ChevronDown size={11} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
          </>
        )}
      </button>

      {open && !loading && (
        <div className="absolute top-full left-0 mt-1.5 w-48 max-h-35 bg-[#080c14] border border-slate-800 rounded-xl overflow-hidden z-50 shadow-xl shadow-black/50 overflow-y-auto">
          {models.map(model => (
            <button
              key={model.id}
              onClick={() => { onChange(model.id); setOpen(false); }}
              className={`w-full flex items-center justify-between px-3 py-2.5 text-left transition-all hover:bg-slate-800/60 ${
                model.id === value ? 'bg-blue-950/40' : ''
              }`}
            >
              <div>
                <p className={`text-[11px] font-mono ${model.id === value ? 'text-blue-300' : 'text-slate-300'}`}>
                  {model.name}
                </p>
                <p className="text-[9px] font-mono text-slate-600 mt-0.5 capitalize">
                  {model.provider}
                </p>
              </div>
              <span className="text-[9px] font-mono text-slate-600 bg-slate-800 px-1.5 py-0.5 rounded">
                {model.credits_per_image}cr
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
